﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSD_233_DAW_DAL.Models
{
    public class ActorModel
    {
        public string ActorFirstName { get; set; }
        public string ActorLastName { get; set; }
    }
}

